<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>Hello_Qt_OpenCV</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="53"/>
        <source>Input Image :</source>
        <translation>Ein Bild :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="63"/>
        <location filename="mainwindow.ui" line="110"/>
        <source>Browse</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="72"/>
        <source>Filter type</source>
        <translation>Filter Tip</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="78"/>
        <source>Median Blur</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="88"/>
        <source>Gaussian Blur</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="100"/>
        <source>Output Image :</source>
        <translation>Aus Bild :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="119"/>
        <source>Display Image After Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="19"/>
        <source>Open Input Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="19"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="28"/>
        <source>Select Output Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="42"/>
        <source>Output Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="48"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="48"/>
        <source>Are you sure you want to close this program?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
