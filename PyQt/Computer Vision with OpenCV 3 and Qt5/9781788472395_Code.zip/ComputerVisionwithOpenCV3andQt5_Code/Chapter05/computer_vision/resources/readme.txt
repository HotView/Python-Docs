These files and folders need to be copied to the exact folder where application executable resides.
On Windows and Linux, this is simply the same folder as the produced executable.
On macOS though, it is inside the package, but again where the executable resides.