'''
May 25,  2015
Recipe:  B04829_01_01
@author: Burkhard Meier
'''
#======================
# imports
#======================
import tkinter as tk

# Create instance
win = tk.Tk()   

# Add a title       
win.title("Python GUI")

#======================
# Start GUI
#======================
win.mainloop()