'''
Created on Aug 27, 2015
Chapter 09
@author: Burkhard
'''

import wx
app = wx.App()
frame = wx.Frame(None, -1, "Hello World")
frame.Show()
app.MainLoop()
