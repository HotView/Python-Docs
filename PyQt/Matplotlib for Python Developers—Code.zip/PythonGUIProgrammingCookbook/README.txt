The code has been tested on the latest version of Eclipse which is Mars.1.
It also has been tested on Windows 10 in addition to Windows 7.

It is expected to run well on Apple Macintosh.

The PyDev version within Eclipse is the latest, which is: PyDev for Eclipse 4.4.0.201510052309	org.python.pydev.feature.feature.group	Fabio Zadrozny

